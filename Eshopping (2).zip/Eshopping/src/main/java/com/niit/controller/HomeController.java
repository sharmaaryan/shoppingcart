package com.niit.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {

	@RequestMapping("/")
	public String welcome()
	{
	return "home";
	}
	@RequestMapping("/login")
	public String loginpage()
	{
		return "login";
	}
	  @RequestMapping("/register")
		public String register()
		{
		return "register";
	    }
	  
	  @RequestMapping("/validate")
	  public String validate (@RequestParam(name="userID")String id,
			  @RequestParam(name="password")String pwd,
			  
			  Model model)
	  {
		  //validate-hit the database to validate
		  //niit
		  
		 
		if (id.equals("nitt") && pwd.equals("niit"))
		  {
			  
			model.addAttribute("successmessage", "you successfull logged in");
		  }
		  else
		  {
			  model.addAttribute("successmessage", "invalid details....please try again");
			  
		  }
	 //Sap
		  return"home";
		  
	 
			
	  }
	  
}
