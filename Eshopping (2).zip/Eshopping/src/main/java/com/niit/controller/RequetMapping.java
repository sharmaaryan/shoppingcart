package com.niit.controller;

public @interface RequetMapping {

}
